# 🪙 Solana Token Info Bot (Render-ready)

This is a minimal Telegram bot that fetches Solana token information (price, liquidity, supply, decimals, etc.) when a user pastes a token contract address (CA).

## How to use

1. Fork or upload this repo to GitHub.
2. On Render:
   - Create **New → Web Service**
   - Connect your GitHub repo
   - Build command: `npm install`
   - Start command: `npm start`
   - Add environment variables in Render Dashboard:
     - `BOT_TOKEN` — your Telegram bot token
     - `RPC_URL` — e.g. `https://api.mainnet-beta.solana.com`
3. Deploy and enjoy — the bot will run 24/7.

## Files
- `.env.example` — example environment variables (do NOT commit your real `.env`).
- `Procfile` — instructs Render how to start the app.
- `package.json` — dependencies & start script.
- `index.js` — main bot code.

## Notes
- This project uses Node 18+.
- If you see "package not found" errors on Render, ensure files are in the repository root and the Build command is `npm install`.
